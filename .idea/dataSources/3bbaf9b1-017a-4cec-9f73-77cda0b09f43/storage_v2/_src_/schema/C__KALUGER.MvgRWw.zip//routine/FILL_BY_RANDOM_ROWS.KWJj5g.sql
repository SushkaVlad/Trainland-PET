create procedure fill_by_random_rows ( innum in integer)
    is
    randomid integer;
    randst integer;
    randlst integer;
    SOURCEID INTEGER;
    OPSUM INTEGER;
begin
    select min(id) into randst from people;
    select max(id) into randlst from people;
    for i in 1..innum loop
            randomid :=trunc(sys.DBMS_random.value((randst),(randlst)));
            LOOP
                SOURCEID:=trunc(sys.DBMS_random.value((randst),(randlst)));
                EXIT WHEN SOURCEID!=randomid;
            end loop;
            OPSUM:=trunc(sys.DBMS_random.value(-200001,200001));
            INSERT INTO people_log(PERSON_ID,source_person_id, SUM,OPERATION_DATE) VALUES (randomid,SOURCEID,OPSUM, TO_DATE('15.01.2017', 'DD.MM.YYYY')+(i-1)/24);
        end loop;
end;
/

