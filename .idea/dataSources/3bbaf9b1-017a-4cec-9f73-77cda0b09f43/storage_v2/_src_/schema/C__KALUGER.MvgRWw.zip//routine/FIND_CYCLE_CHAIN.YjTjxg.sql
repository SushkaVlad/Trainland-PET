create FUNCTION Find_Cycle_chain
    RETURN INTEGER
    IS
    Beginner Integer:=0;
    Beginner_source INTEGER:=0;
    CURRENT_PERSON_ID Integer:=0;
    Cycles_q Integer:=0;
    COUNTER INTEGER:=1;
    CURDATE DATE;
    CURSOURCEID INTEGER:=0;
    CURRENTTRANZ PEOPLE_LOG%ROWTYPE;
BEGIN
    SELECT * INTO CURRENTTRANZ FROM people_log ORDER BY operation_date FETCH FIRST 1 ROW ONLY;
    Beginner:=CURRENTTRANZ.person_id;
    CURRENT_PERSON_ID:=CURRENTTRANZ.person_id;
    LOOP
        SELECT * INTO CURRENTTRANZ FROM people_log WHERE source_person_id=CURRENT_PERSON_ID AND operation_date>CURDATE
        ORDER BY operation_date FETCH FIRST 1 ROW ONLY;
        CURRENT_PERSON_ID:=CURRENTTRANZ.person_id;
        COUNTER:=COUNTER+1;
        if CURRENT_PERSON_ID=Beginner --and CURRENTTRANZ.source_person_id=Beginner_source
         then Cycles_q:=Cycles_q+1; end if;
        if Cycles_q=2 and COUNTER>=8 then DBMS_OUTPUT.PUT_LINE('Обнаружена циклическая транзакция из четырех человек, ' ||
                                                               'в ходе которой деньги проходят два раза через одного человека'); EXIT; end if;
        CURDATE:=CURRENTTRANZ.operation_date;
    end loop;
EXCEPTION
    WHEN NO_DATA_FOUND THEN RETURN COUNTER;
end;
/

