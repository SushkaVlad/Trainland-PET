create FUNCTION        LOGMNR$GSBA_GG_TABF_PUBLIC wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
204 16d
TJgbwETdggmXz74u7w/JrOCMLZUwgwLIr0hGfHSiEv/qVCcobaDmzQ1NW9NZS4lXFtygg175
tZarVC/jhB662Fj0ml9YLlHdj6yBdiTYfbxUuglkxmUXzYWprDJI/x819+U/W/+HCzSEVTo4
eyQupUEJ82oFYTEdyuCX9zVB8VDEnCzvqzdYyfXbV6b0CW2Ewgo4dfm4MlwRwDYuaMYXqNwR
fxX+KM+f8oxs4qwnmjQByrcYKddGnKCC7kqfOEW7VrXXUkLrYhQhQThaJ63/NezIPczX5qxx
7sY9gkBTrPNqH6DNPg4qqMfl0x8VNJCg9Vt/eo+ffUg9GSESima5hw28P14yBe1z4RIYP0Y=

/

